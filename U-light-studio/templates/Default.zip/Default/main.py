from moduls.Ulight import *


while True:
    scene.run()