import pygame

# window setings

WIDTH_SCREEN = 1200
HEIGHT_SCREEN = 600
NAME_SCREEN = 'Ulight_game_engine'
ICON_SCREEN = 'light.png'

# mouse variable

MOUSE_POS = pygame.mouse.get_pos()
MOUSE_CLICK = pygame.mouse.get_pressed()
MOUSE_VISIBLE_NO = pygame.mouse.set_visible(False)
MOUSE_VISIBLE_YES = pygame.mouse.set_visible(True)

screen = pygame.display.set_mode((WIDTH_SCREEN, HEIGHT_SCREEN))
pygame.display.set_caption(NAME_SCREEN)
pygame.display.set_icon(pygame.image.load(ICON_SCREEN))

class scene:
    def run():
        for event in pygame.event.get:
            if event.type == pygame.QUIT:
                quit()

class P2D:
    def RECT(pos=(0, 0), size=(100, 100), color=(255, 255, 255), mode='create'):
        if mode == 'create':
            pygame.display.rect(screen, color, (*pos, *size))
            if pos[0] < MOUSE_POS[0] < pos[0]+size[0]:
                if pos[1] < MOUSE_POS[1] < pos[1]+size[1]:
                    if MOUSE_CLICK[0]:
                        pos[0]=MOUSE_POS[0]
                        pos[1]=MOUSE_POS[1]
                    if MOUSE_CLICK[3]:
                        pos[0]=MOUSE_POS[0]
                        pos[1]=MOUSE_POS[1]
                
        if mode == 'game':
            pygame.display.rect(screen, color, (*pos, *size))
    
    def BUTTON(pos=(0, 0), size=(100, 100), color=(255, 255, 255), task='debug', mode='create'):
        if mode == 'create':
            pygame.display.rect(screen, color, (*pos, *size))
            
            if pos[0] < MOUSE_POS[0] < pos[0]+size[0]:
                if pos[1] < MOUSE_POS[1] < pos[1]+size[1]:
                    if MOUSE_CLICK[0]:
                        pos[0]=MOUSE_POS[0]
                        pos[1]=MOUSE_POS[1]
                    if MOUSE_CLICK[3]:
                        pos[0]=MOUSE_POS[0]
                        pos[1]=MOUSE_POS[1]
                        
        if mode == 'game':
            pygame.display.rect(screen, color, (*pos, *size))
            
            if pos[0] < MOUSE_POS[0] < pos[0]+size[0]:
                if pos[1] < MOUSE_POS[1] < pos[1]+size[1]:
                    if task=='debug':
                        print('press')
                    else:
                        task()